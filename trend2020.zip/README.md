# trend2020
TRENDS - 2020
